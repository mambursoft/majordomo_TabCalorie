<?php
/**
 * TabCalorie storage layer. All SQL goes through MajorDoMo helpers.
 *
 * @package tabcalorie
 * @license MIT
 */

class TabCalorieStore
{
    /** pvalues.VALUE is TEXT (64 KB) in MajorDoMo - keep a safe byte margin. */
    const MAX_RAW_BYTES = 60000;

    /** Parse "1 234,5" / "1,234.5" / "12.5" / null into float. */
    public static function num($value)
    {
        if ($value === null || $value === '' || is_array($value)) {
            return 0.0;
        }
        if (is_numeric($value)) {
            return (float)$value;
        }
        $s = str_replace(array("\xc2\xa0", ' ', "\t", "'"), '', (string)$value);
        if (!preg_match('/[0-9]/', $s)) {
            return 0.0;
        }
        $comma = strrpos($s, ',');
        $dot = strrpos($s, '.');
        if ($comma !== false && $dot !== false) {
            if ($comma > $dot) {
                $s = str_replace('.', '', $s);
                $s = str_replace(',', '.', $s);
            } else {
                $s = str_replace(',', '', $s);
            }
        } elseif ($comma !== false) {
            $s = str_replace(',', '.', $s);
        }
        if (!preg_match('/^[+-]?[0-9]*\.?[0-9]+(?:[eE][+-]?[0-9]+)?$/', $s)) {
            return 0.0;
        }
        return (float)$s;
    }

    public static function round1($v)
    {
        return round((float)$v, 1);
    }

    /**
     * Parse "166 x 1 g" or "2 x 200 ml" into total quantity and unit label.
     * The API stores count x unit-multiplier, so both parts are multiplied.
     */
    public static function parseUnit($raw)
    {
        $raw = trim((string)$raw);
        $raw = str_replace("\xd1\x85", 'x', $raw); // Cyrillic "х" -> "x"
        if (preg_match('/([0-9]+(?:[.,][0-9]+)?)\s*(г|кг|мл|л|g|ml|kg|l)\s*\)/iu', $raw, $m)) {
            $q = self::num($m[1]);
            if (stripos($m[2], 'кг') === 0 || strtolower($m[2]) === 'kg') {
                $q *= 1000;
            }
            return array($q, mb_strtolower($m[2], 'UTF-8'));
        }
        if (preg_match('/^([0-9]+(?:[.,][0-9]+)?)\s*x\s*([0-9]+(?:[.,][0-9]+)?)\s*(.+)$/iu', $raw, $m)) {
            return array(self::num($m[1]) * self::num($m[2]), trim($m[3]));
        }
        if (preg_match('/^([0-9]+(?:[.,][0-9]+)?)\s*x\s*(.+)$/iu', $raw, $m)) {
            return array(self::num($m[1]), trim($m[2]));
        }
        if (preg_match('/^([0-9]+(?:[.,][0-9]+)?)\s*(г|кг|мл|л|g|ml|kg|l|шт|ks|pc)\b/iuU', $raw, $m)) {
            $q = self::num($m[1]);
            $unit = mb_strtolower($m[2], 'UTF-8');
            if (in_array($unit, array('кг', 'kg'), true)) {
                $q *= 1000;
                $unit = 'g';
            }
            return array($q, $unit);
        }
        return array(0.0, $raw);
    }

    /**
     * Unique key for an entry. Includes the API item id so two identical foods
     * with the same weight inside one meal stay two separate records.
     */
    private static function entryKey($date, $slotId, $foodGuid, $unitRaw, $itemId = '')
    {
        return md5($date . '|' . $slotId . '|' . $foodGuid . '|' . $unitRaw . '|' . $itemId);
    }

    /**
     * Convert one diary response into normalized entry rows.
     * @return array rows ready for upsert
     */
    public static function parseDiary($diary, $date)
    {
        $rows = array();
        if (!is_array($diary)) {
            return $rows;
        }
        $times = isset($diary['times']) && is_array($diary['times']) ? $diary['times'] : array();
        foreach ($times as $idx => $slot) {
            if (!is_array($slot)) {
                continue;
            }
            $slotId = (int)(isset($slot['id']) ? $slot['id'] : ($idx + 1));
            $slotTitle = isset($slot['title']) ? (string)$slot['title'] : '';
            $mealTime = '';
            foreach (array('time', 'timeUser', 'timeFrom') as $timeKey) {
                if (!empty($slot[$timeKey]) && is_scalar($slot[$timeKey])) {
                    $candidate = trim((string)$slot[$timeKey]);
                    if (preg_match('/^\d{1,2}:\d{2}/', $candidate)) {
                        $mealTime = mb_substr($candidate, 0, 5);
                        break;
                    }
                }
            }
            $foods = isset($slot['foodstuff']) && is_array($slot['foodstuff']) ? $slot['foodstuff'] : array();
            foreach ($foods as $itemIdx => $item) {
                if (!is_array($item)) {
                    continue;
                }
                $itemId = isset($item['id']) && $item['id'] !== ''
                    ? (string)$item['id'] : ('idx' . $itemIdx);
                $title = isset($item['title']) ? trim((string)$item['title']) : '';
                if ($title === '') {
                    continue;
                }
                $unitRaw = isset($item['unit']) ? (string)$item['unit'] : '';
                $foodGuid = isset($item['guidType']) && $item['guidType'] ? (string)$item['guidType'] : '';
                if ($foodGuid === '' && isset($item['id'])) {
                    $foodGuid = (string)$item['id'];
                }
                if ($foodGuid === '') {
                    $foodGuid = md5($title . '|' . $unitRaw);
                }
                list($quantity, $unit) = self::parseUnit($unitRaw);
                $row = array(
                    'ITEM_ID' => $itemId,
                    'ENTRY_KEY' => self::entryKey($date, $slotId, $foodGuid, $unitRaw, $itemId),
                    'ENTRY_DATE' => $date,
                    'SLOT_ID' => $slotId,
                    'SLOT_TITLE' => $slotTitle,
                    'MEAL_TIME' => $mealTime,
                    'TITLE' => $title,
                    'FOOD_GUID' => $foodGuid,
                    'FOOD_URL' => isset($item['url']) ? (string)$item['url'] : '',
                    'UNIT_RAW' => $unitRaw,
                    'QUANTITY' => $quantity,
                    'UNIT' => $unit,
                    'ENERGY' => self::num(isset($item['energy']) ? $item['energy'] : 0),
                    'PROTEIN' => self::num(isset($item['protein']) ? $item['protein'] : 0),
                    'FAT' => self::num(isset($item['fat']) ? $item['fat'] : 0),
                    'CARBOHYDRATE' => self::num(isset($item['carbohydrate']) ? $item['carbohydrate'] : 0),
                    'FIBER' => self::num(isset($item['fiber']) ? $item['fiber'] : 0),
                    'SUGAR' => self::num(isset($item['sugar']) ? $item['sugar'] : 0),
                    'SOURCE' => 'tk',
                    'SYNCED_AT' => date('Y-m-d H:i:s'),
                );
                $rows[] = $row;
            }
        }
        return $rows;
    }

    /**
     * Parse the `activities` array returned by the diary endpoint.
     * Health Connect activity is synced INTO TK, so this is read-only here.
     */
    public static function parseActivities($diary, $date)
    {
        $rows = array();
        if (!is_array($diary) || empty($diary['activities']) || !is_array($diary['activities'])) {
            return $rows;
        }
        foreach ($diary['activities'] as $idx => $a) {
            if (!is_array($a)) {
                continue;
            }
            $id = isset($a['id']) && $a['id'] !== '' ? (string)$a['id'] : '';
            if ($id === '' && isset($a['guidType'])) {
                $id = (string)$a['guidType'];
            }
            $title = isset($a['title']) ? trim((string)$a['title']) : '';
            if ($id === '' && $title === '') {
                continue;
            }
            if ($id === '') {
                $id = md5($title . '|' . $date . '|' . $idx);
            }
            $energy = self::num(isset($a['energy']) ? $a['energy'] : 0);
            $unit = isset($a['energyUnit']) ? (string)$a['energyUnit'] : 'kcal';
            if (stripos($unit, 'kj') !== false) {
                $energy = $energy / 4.184;
                $unit = 'kcal';
            }
            $rows[] = array(
                'ACTIVITY_KEY' => md5($date . '|' . $id),
                'ACTIVITY_DATE' => $date,
                'ACTIVITY_ID' => $id,
                'TITLE' => $title,
                'TYPE' => isset($a['type']) ? (string)$a['type'] : 'activity',
                'ACTIVITY_TYPE' => isset($a['activityType']) ? (string)$a['activityType'] : '',
                'STEPS' => self::round1(self::num(isset($a['steps']) ? $a['steps'] : 0)),
                'ENERGY' => self::round1($energy),
                'UNIT' => $unit,
                'DURATION' => self::round1(self::num(isset($a['duration']) ? $a['duration'] : 0)),
                'RAW_JSON' => mb_substr(json_encode($a, JSON_UNESCAPED_UNICODE), 0, 4000),
                'SYNCED_AT' => date('Y-m-d H:i:s'),
            );
        }
        return $rows;
    }

    /** Idempotent insert/update of activity rows. */
    public static function saveActivities($rows)
    {
        $count = 0;
        foreach ($rows as $row) {
            $key = DBSafe($row['ACTIVITY_KEY']);
            $old = SQLSelectOne("SELECT ID FROM tabcalorie_activities WHERE ACTIVITY_KEY='" . $key . "'");
            $record = $row;
            if ($old['ID']) {
                $record['ID'] = $old['ID'];
                SQLUpdate('tabcalorie_activities', $record);
            } else {
                SQLInsert('tabcalorie_activities', $record);
            }
            $count++;
        }
        return $count;
    }

    /** Idempotent insert/update of parsed rows. Returns affected row count. */
    public static function saveEntries($rows)
    {
        $count = 0;
        foreach ($rows as $row) {
            $key = DBSafe($row['ENTRY_KEY']);
            $old = SQLSelectOne("SELECT ID FROM tabcalorie_entries WHERE ENTRY_KEY='" . $key . "'");
            $record = $row;
            if ($old['ID']) {
                $record['ID'] = $old['ID'];
                SQLUpdate('tabcalorie_entries', $record);
            } else {
                SQLInsert('tabcalorie_entries', $record);
            }
            $count++;
        }
        return $count;
    }

    /** Recompute and store daily totals from entries. */
    public static function saveDay($date, $diary = null, $cfg = array())
    {
        $activityEnabled = !isset($cfg['ACTIVITY_ENABLED']) || (int)$cfg['ACTIVITY_ENABLED'] === 1;
        $sql = "SELECT
                    COUNT(*) AS CNT,
                    SUM(ENERGY) AS ENERGY,
                    SUM(PROTEIN) AS PROTEIN,
                    SUM(FAT) AS FAT,
                    SUM(CARBOHYDRATE) AS CARB,
                    SUM(FIBER) AS FIBER,
                    SUM(SUGAR) AS SUGAR,
                    COUNT(DISTINCT SLOT_ID) AS SLOTS
                FROM tabcalorie_entries WHERE ENTRY_DATE='" . DBSafe($date) . "'";
        $sum = SQLSelectOne($sql);
        $carbs = self::round1(isset($sum['CARB']) ? $sum['CARB'] : 0);
        $old = SQLSelectOne("SELECT * FROM tabcalorie_days WHERE DAY_DATE='" . DBSafe($date) . "'");
        $act = SQLSelectOne("SELECT SUM(STEPS) AS S, SUM(ENERGY) AS E, COUNT(*) AS N
                             FROM tabcalorie_activities WHERE ACTIVITY_DATE='" . DBSafe($date) . "'");
        $day = array(
            'DAY_DATE' => $date,
            'ENERGY' => self::round1(isset($sum['ENERGY']) ? $sum['ENERGY'] : 0),
            'PROTEIN' => self::round1(isset($sum['PROTEIN']) ? $sum['PROTEIN'] : 0),
            'FAT' => self::round1(isset($sum['FAT']) ? $sum['FAT'] : 0),
            'CARBOHYDRATE' => $carbs,
            'FIBER' => self::round1(isset($sum['FIBER']) ? $sum['FIBER'] : 0),
            'SUGAR' => self::round1(isset($sum['SUGAR']) ? $sum['SUGAR'] : 0),
            'FOODSTUFF_COUNT' => (int)(isset($sum['CNT']) ? $sum['CNT'] : 0),
            'SLOT_COUNT' => (int)(isset($sum['SLOTS']) ? $sum['SLOTS'] : 0),
            'STEPS' => $activityEnabled ? self::round1(isset($act['S']) ? $act['S'] : 0) : 0,
            'ACTIVITY_KCAL' => $activityEnabled ? self::round1(isset($act['E']) ? $act['E'] : 0) : 0,
            'ACTIVITY_COUNT' => $activityEnabled ? (int)(isset($act['N']) ? $act['N'] : 0) : 0,
            'RAW_JSON' => $old['RAW_JSON'],
            'UPDATED' => date('Y-m-d H:i:s'),
        );
        // Keep notes from the diary slot level (API has no per-food notes).
        $notes = array();
        if (is_array($diary) && isset($diary['times']) && is_array($diary['times'])) {
            foreach ($diary['times'] as $slot) {
                if (is_array($slot) && isset($slot['notes']) && is_array($slot['notes'])) {
                    foreach ($slot['notes'] as $note) {
                        if (is_array($note)) {
                            $note = isset($note['title']) ? $note['title'] : json_encode($note);
                        }
                        $note = trim(strip_tags((string)$note));
                        if ($note !== '') {
                            $notes[] = $note;
                        }
                    }
                }
            }
        }
        $day['NOTES'] = mb_substr(implode(' | ', $notes), 0, 1000);
        if (is_array($diary)) {
            $raw = json_encode($diary, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $day['RAW_JSON'] = mb_strcut((string)$raw, 0, self::MAX_RAW_BYTES, 'UTF-8');
        }
        if ($old['ID']) {
            $day['ID'] = $old['ID'];
            SQLUpdate('tabcalorie_days', $day);
        } else {
            SQLInsert('tabcalorie_days', $day);
        }
        return $day;
    }

    /** Most recent date that actually has entries (never skip to another day). */
    public static function lastFilledDate()
    {
        $rec = SQLSelectOne("SELECT MAX(ENTRY_DATE) AS D FROM tabcalorie_entries");
        return isset($rec['D']) && $rec['D'] ? $rec['D'] : date('Y-m-d');
    }

    /** Aggregation for the last filled day: 6 slots + 3 groups. */
    public static function overview($date = null)
    {
        if (!$date) {
            $date = self::lastFilledDate();
        }
        $day = SQLSelectOne("SELECT * FROM tabcalorie_days WHERE DAY_DATE='" . DBSafe($date) . "'");
        if (!$day['ID']) {
            $day = array('DAY_DATE' => $date, 'CARBOHYDRATE' => 0, 'ENERGY' => 0,
                'PROTEIN' => 0, 'FAT' => 0, 'FIBER' => 0, 'SUGAR' => 0,
                'SLOT_COUNT' => 0, 'FOODSTUFF_COUNT' => 0, 'NOTES' => '');
        }
        $slots = array();
        for ($i = 1; $i <= 6; $i++) {
            $slots[$i] = array('id' => $i, 'title_key' => self::slotKey($i), 'carbs' => 0.0,
                'kcal' => 0.0, 'protein' => 0.0, 'fat' => 0.0, 'fiber' => 0.0,
                'sugar' => 0.0, 'count' => 0, 'present' => false);
        }
        $rows = SQLSelect("SELECT SLOT_ID, SUM(CARBOHYDRATE) AS C, SUM(ENERGY) AS E,
                           SUM(PROTEIN) AS P, SUM(FAT) AS F, SUM(FIBER) AS FI, SUM(SUGAR) AS S,
                           COUNT(*) AS N
                           FROM tabcalorie_entries WHERE ENTRY_DATE='" . DBSafe($date) . "'
                           GROUP BY SLOT_ID");
        foreach ($rows as $r) {
            $id = (int)$r['SLOT_ID'];
            if (isset($slots[$id])) {
                $slots[$id]['carbs'] = self::round1($r['C']);
                $slots[$id]['kcal'] = self::round1($r['E']);
                $slots[$id]['protein'] = self::round1($r['P']);
                $slots[$id]['fat'] = self::round1($r['F']);
                $slots[$id]['fiber'] = self::round1($r['FI']);
                $slots[$id]['sugar'] = self::round1($r['S']);
                $slots[$id]['count'] = (int)$r['N'];
                $slots[$id]['present'] = true;
            }
        }
        $main = $slots[1]['carbs'] + $slots[3]['carbs'] + $slots[5]['carbs'];
        $snacks = $slots[2]['carbs'] + $slots[4]['carbs'] + $slots[6]['carbs'];
        return array(
            'date' => $date,
            'partial' => ((int)(isset($day['SLOT_COUNT']) ? $day['SLOT_COUNT'] : 0) < 6),
            'slot_count' => (int)(isset($day['SLOT_COUNT']) ? $day['SLOT_COUNT'] : 0),
            'slots' => $slots,
            'groups' => array('main' => self::round1($main), 'snacks' => self::round1($snacks),
                'day' => self::round1($main + $snacks)),
            'total_carbs' => self::round1(isset($day['CARBOHYDRATE']) ? $day['CARBOHYDRATE'] : ($main + $snacks)),
            'total_kcal' => self::round1(isset($day['ENERGY']) ? $day['ENERGY'] : 0),
            'protein' => self::round1(isset($day['PROTEIN']) ? $day['PROTEIN'] : 0),
            'fat' => self::round1(isset($day['FAT']) ? $day['FAT'] : 0),
            'fiber' => self::round1(isset($day['FIBER']) ? $day['FIBER'] : 0),
            'sugar' => self::round1(isset($day['SUGAR']) ? $day['SUGAR'] : 0),
            'notes' => isset($day['NOTES']) ? (string)$day['NOTES'] : '',
            'steps' => self::round1(isset($day['STEPS']) ? $day['STEPS'] : 0),
            'activity_kcal' => self::round1(isset($day['ACTIVITY_KCAL']) ? $day['ACTIVITY_KCAL'] : 0),
            'activity_count' => (int)(isset($day['ACTIVITY_COUNT']) ? $day['ACTIVITY_COUNT'] : 0),
        );
    }

    public static function slotKey($id)
    {
        $keys = array(1 => 'TC_BREAKFAST', 2 => 'TC_SNACK1', 3 => 'TC_LUNCH',
            4 => 'TC_SNACK2', 5 => 'TC_DINNER', 6 => 'TC_LATE_DINNER');
        return isset($keys[(int)$id]) ? $keys[(int)$id] : 'TC_MEAL';
    }

    /** Meal time from the API, with a conventional fallback schedule. */
    public static function mealTime($slotId, $raw = '')
    {
        $raw = trim((string)$raw);
        if (preg_match('/^\d{1,2}:\d{2}/', $raw)) {
            return mb_substr($raw, 0, 5);
        }
        $defaults = array(1 => '08:00', 2 => '10:00', 3 => '13:00',
            4 => '16:00', 5 => '19:00', 6 => '22:00');
        return isset($defaults[(int)$slotId]) ? $defaults[(int)$slotId] : '';
    }

    /**
     * Daily norm share for one meal slot.
     * Main meals (1,3,5) receive MEAL_NORM_SHARE percent each; the remainder is
     * split evenly between the three snack slots (2,4,6).
     */
    public static function mealShare($slotId, $sharePercent)
    {
        $share = max(10, min(50, (float)$sharePercent)) / 100;
        $id = (int)$slotId;
        if (in_array($id, array(1, 3, 5), true)) {
            return $share <= 1 / 3 ? $share : 1 / 3;
        }
        if (in_array($id, array(2, 4, 6), true)) {
            return $share <= 1 / 3 ? (1 - 3 * $share) / 3 : 0;
        }
        return 0;
    }

    /** Norm for a given meal and metric (carbs/protein/fat/kcal). */
    public static function mealNorm($dailyTarget, $slotId, $sharePercent)
    {
        return self::round1(max(0, (float)$dailyTarget) * self::mealShare($slotId, $sharePercent));
    }

    /** Names of every property of the TabCalorie object. */
    public static function objectPropertyNames()
    {
        $props = array('LastDate', 'Partial', 'FilledSlots', 'GroupMainCarbs',
            'GroupSnacksCarbs', 'GroupDayCarbs', 'TotalCarbs', 'TotalKcal',
            'TotalProtein', 'TotalFat', 'TotalFiber', 'TotalSugar', 'TotalXE',
            'GI', 'Notes', 'Updated', 'Status', 'Raw',
            'ActivitySteps', 'ActivityKcal', 'ActivityCount');
        for ($i = 1; $i <= 6; $i++) {
            $props[] = 'Slot' . $i . 'Carbs';
            $props[] = 'Slot' . $i . 'Kcal';
            $props[] = 'Slot' . $i . 'Protein';
            $props[] = 'Slot' . $i . 'Fat';
        }
        return $props;
    }

    /** Create all class properties with localized descriptions in properties.DESCRIPTION. */
    public static function ensureClassProperties()
    {
        if (!function_exists('addClass') || !function_exists('addClassProperty')) {
            return false;
        }
        addClass('STabCalorie');
        $descriptions = self::propertyDescriptions();
        foreach (self::objectPropertyNames() as $name) {
            $history = (strpos($name, 'Carbs') !== false || strpos($name, 'Total') === 0) ? 365 : 0;
            $id = addClassProperty('STabCalorie', $name, $history);
            if (!$id) {
                continue;
            }
            $rec = SQLSelectOne("SELECT ID, DESCRIPTION FROM properties WHERE ID=" . (int)$id);
            $current = trim((string)(isset($rec['DESCRIPTION']) ? $rec['DESCRIPTION'] : ''));
            $wanted = isset($descriptions[$name]) ? $descriptions[$name] : $name;
            if ($rec['ID'] && $current !== $wanted) {
                $rec['DESCRIPTION'] = $wanted;
                SQLUpdate('properties', $rec);
            }
        }
        addClassObject('STabCalorie', 'TabCalorie', 'tabcalorie');
        return true;
    }

    /** Localized property descriptions (uk / en / ru). */
    public static function propertyDescriptions($lang = '')
    {
        if ($lang === '') {
            $lang = defined('SETTINGS_SITE_LANGUAGE') ? strtolower(SETTINGS_SITE_LANGUAGE) : 'uk';
        }
        if (!in_array($lang, array('uk', 'ua', 'en', 'ru'), true)) {
            $lang = 'uk';
        }
        $meals = array(
            'uk' => array(1 => 'сніданок', 2 => 'перекус', 3 => 'обід', 4 => 'підвечірок', 5 => 'вечеря', 6 => 'друга вечеря'),
            'ua' => array(1 => 'сніданок', 2 => 'перекус', 3 => 'обід', 4 => 'підвечірок', 5 => 'вечеря', 6 => 'друга вечеря'),
            'en' => array(1 => 'breakfast', 2 => 'snack', 3 => 'lunch', 4 => 'afternoon snack', 5 => 'dinner', 6 => 'late dinner'),
            'ru' => array(1 => 'завтрак', 2 => 'перекус', 3 => 'обед', 4 => 'полдник', 5 => 'ужин', 6 => 'второй ужин'),
        );
        $base = array(
            'LastDate' => array('uk' => 'Дата останньої заповненої доби', 'en' => 'Date of the last filled day', 'ru' => 'Дата последнего заполненного дня'),
            'Partial' => array('uk' => 'День частково заповнений: 1 — так, 0 — ні', 'en' => 'Partially filled day: 1 yes, 0 no', 'ru' => 'День заполнен частично: 1 — да, 0 — нет'),
            'FilledSlots' => array('uk' => 'Кількість заповнених прийомів їжі (0–6)', 'en' => 'Number of filled meal slots (0–6)', 'ru' => 'Количество заполненных приёмов пищи (0–6)'),
            'GroupMainCarbs' => array('uk' => 'Вуглеводи основних прийомів (сніданок, обід, вечеря), г', 'en' => 'Carbs of main meals (breakfast, lunch, dinner), g', 'ru' => 'Углеводы основных приёмов (завтрак, обед, ужин), г'),
            'GroupSnacksCarbs' => array('uk' => 'Вуглеводи перекусів, г', 'en' => 'Carbs of snacks, g', 'ru' => 'Углеводы перекусов, г'),
            'GroupDayCarbs' => array('uk' => 'Сума вуглеводів за добу, г', 'en' => 'Daily carbohydrate total, g', 'ru' => 'Сумма углеводов за день, г'),
            'TotalCarbs' => array('uk' => 'Вуглеводи за останню заповнену добу, г', 'en' => 'Carbs for the last filled day, g', 'ru' => 'Углеводы за последний заполненный день, г'),
            'TotalKcal' => array('uk' => 'Калорійність за добу, ккал', 'en' => 'Daily energy intake, kcal', 'ru' => 'Калорийность за день, ккал'),
            'TotalProtein' => array('uk' => 'Білки за добу, г', 'en' => 'Daily protein, g', 'ru' => 'Белки за день, г'),
            'TotalFat' => array('uk' => 'Жири за добу, г', 'en' => 'Daily fat, g', 'ru' => 'Жиры за день, г'),
            'TotalFiber' => array('uk' => 'Клітковина за добу, г', 'en' => 'Daily fiber, g', 'ru' => 'Клетчатка за день, г'),
            'TotalSugar' => array('uk' => 'Цукри за добу, г', 'en' => 'Daily sugars, g', 'ru' => 'Сахара за день, г'),
            'TotalXE' => array('uk' => 'Хлібні одиниці за добу', 'en' => 'Daily bread units', 'ru' => 'Хлебные единицы за день'),
            'GI' => array('uk' => 'Середній глікемічний індекс страв за добу', 'en' => 'Average glycemic index of the day', 'ru' => 'Средний гликемический индекс блюд за день'),
            'Notes' => array('uk' => 'Нотатки до прийомів їжі', 'en' => 'Notes attached to meals', 'ru' => 'Заметки к приёмам пищи'),
            'Updated' => array('uk' => 'Час останнього оновлення властивостей', 'en' => 'Last property update time', 'ru' => 'Время последнего обновления свойств'),
            'Status' => array('uk' => 'Стан інтеграції: 1 — OK, 0 — помилка або вимкнений цикл', 'en' => 'Integration status: 1 OK, 0 error or disabled cycle', 'ru' => 'Состояние интеграции: 1 — ОК, 0 — ошибка или выключенный цикл'),
            'Raw' => array('uk' => 'Сирі дані ТК за останню заповнену добу (JSON)', 'en' => 'Raw TK data for the last filled day (JSON)', 'ru' => 'Сырые данные ТК за последний заполненный день (JSON)'),
            'ActivitySteps' => array('uk' => 'Кроки за добу (Health Connect)', 'en' => 'Daily steps (Health Connect)', 'ru' => 'Шаги за день (Health Connect)'),
            'ActivityKcal' => array('uk' => 'Спалені калорії за добу (Health Connect)', 'en' => 'Daily burned calories (Health Connect)', 'ru' => 'Сожжённые калории за день (Health Connect)'),
            'ActivityCount' => array('uk' => 'Кількість активностей за добу', 'en' => 'Number of activities per day', 'ru' => 'Количество активностей за день'),
        );
        $templates = array(
            'Carbs' => array('uk' => 'Вуглеводи на %s, г', 'en' => 'Carbs at %s, g', 'ru' => 'Углеводы на %s, г'),
            'Kcal' => array('uk' => 'Калорії на %s, ккал', 'en' => 'Calories at %s, kcal', 'ru' => 'Калории на %s, ккал'),
            'Protein' => array('uk' => 'Білки на %s, г', 'en' => 'Protein at %s, g', 'ru' => 'Белки на %s, г'),
            'Fat' => array('uk' => 'Жири на %s, г', 'en' => 'Fat at %s, g', 'ru' => 'Жиры на %s, г'),
        );
        for ($i = 1; $i <= 6; $i++) {
            foreach ($templates as $suffix => $tpl) {
                $base['Slot' . $i . $suffix] = array(
                    'uk' => sprintf($tpl['uk'], $meals['uk'][$i]),
                    'en' => sprintf($tpl['en'], $meals['en'][$i]),
                    'ru' => sprintf($tpl['ru'], $meals['ru'][$i]),
                );
            }
        }
        $out = array();
        foreach ($base as $name => $values) {
            $out[$name] = isset($values[$lang]) ? $values[$lang] : $values['uk'];
        }
        return $out;
    }

    /** Return the MajorDoMo object with per-meal aggregates for the last filled day. */
    public static function updateObject($overview, $gramsPerXe = 10, $cfg = array())
    {
        if (!function_exists('addClass') || !function_exists('getObject')) {
            return false;
        }
        self::ensureClassProperties();
        $obj = getObject('TabCalorie');
        if (!$obj) {
            return false;
        }
        $values = array(
            'LastDate' => $overview['date'],
            'Partial' => $overview['partial'] ? 1 : 0,
            'FilledSlots' => $overview['slot_count'],
            'GroupMainCarbs' => $overview['groups']['main'],
            'GroupSnacksCarbs' => $overview['groups']['snacks'],
            'GroupDayCarbs' => $overview['groups']['day'],
            'TotalCarbs' => $overview['total_carbs'],
            'TotalKcal' => $overview['total_kcal'],
            'TotalProtein' => $overview['protein'],
            'TotalFat' => $overview['fat'],
            'TotalFiber' => $overview['fiber'],
            'TotalSugar' => $overview['sugar'],
            'TotalXE' => self::round1($overview['total_carbs'] / max(1, (float)$gramsPerXe)),
            'GI' => self::averageGi($overview['date']),
            'Notes' => $overview['notes'],
            'Updated' => date('Y-m-d H:i:s'),
            'Status' => self::computeStatus($cfg),
            'Raw' => self::rawPayload($overview['date']),
            'ActivitySteps' => isset($overview['steps']) ? $overview['steps'] : 0,
            'ActivityKcal' => isset($overview['activity_kcal']) ? $overview['activity_kcal'] : 0,
            'ActivityCount' => isset($overview['activity_count']) ? $overview['activity_count'] : 0,
        );
        for ($i = 1; $i <= 6; $i++) {
            $values['Slot' . $i . 'Carbs'] = $overview['slots'][$i]['carbs'];
            $values['Slot' . $i . 'Kcal'] = $overview['slots'][$i]['kcal'];
            $values['Slot' . $i . 'Protein'] = $overview['slots'][$i]['protein'];
            $values['Slot' . $i . 'Fat'] = $overview['slots'][$i]['fat'];
        }
        foreach ($values as $name => $value) {
            $obj->setProperty($name, $value, 0, 'tabcalorie');
        }
        return true;
    }

    /**
     * Lightweight Status refresh for page loads and failure paths.
     * Raw is intentionally NOT written here: it is large and is refreshed by
     * updateObject() after a real sync only.
     */
    public static function refreshStatusObject($cfg)
    {
        if (!function_exists('getObject')) {
            return false;
        }
        $obj = @getObject('TabCalorie');
        if (!$obj) {
            return false;
        }
        $obj->setProperty('Status', self::computeStatus($cfg), 0, 'tabcalorie');
        return true;
    }

    /** Weighted average GI from the local food dictionary. */
    public static function averageGi($date)
    {
        $rows = SQLSelect("SELECT e.FOOD_GUID, e.QUANTITY, f.GI
                           FROM tabcalorie_entries e
                           LEFT JOIN tabcalorie_foods f ON f.FOOD_GUID=e.FOOD_GUID
                           WHERE e.ENTRY_DATE='" . DBSafe($date) . "' AND f.GI>0");
        $sum = 0.0;
        $weight = 0.0;
        foreach ($rows as $r) {
            $w = self::num($r['QUANTITY']);
            if ($w <= 0) {
                $w = 1;
            }
            $sum += self::num($r['GI']) * $w;
            $weight += $w;
        }
        return $weight > 0 ? self::round1($sum / $weight) : 0.0;
    }

    /** Rebuild the per-100 g food dictionary from imported entries. */
    public static function rebuildFoods()
    {
        $rows = SQLSelect("SELECT FOOD_GUID, TITLE, UNIT, MAX(FOOD_URL) AS FOOD_URL,
                    SUM(QUANTITY) AS Q, COUNT(*) AS CNT,
                    SUM(ENERGY) AS E, SUM(PROTEIN) AS P, SUM(FAT) AS F,
                    SUM(CARBOHYDRATE) AS C, SUM(FIBER) AS FI, SUM(SUGAR) AS S
                   FROM tabcalorie_entries
                   GROUP BY FOOD_GUID, TITLE, UNIT");
        $n = 0;
        foreach ($rows as $r) {
            $q = self::num($r['Q']);
            if ($q <= 0) {
                continue;
            }
            $k = 100 / $q;
            $rec = array(
                'FOOD_GUID' => $r['FOOD_GUID'],
                'FOOD_ID' => $r['FOOD_GUID'],
                'TITLE' => $r['TITLE'],
                'UNIT' => $r['UNIT'],
                'ENERGY_100' => self::round1(self::num($r['E']) * $k),
                'PROTEIN_100' => self::round1(self::num($r['P']) * $k),
                'FAT_100' => self::round1(self::num($r['F']) * $k),
                'CARB_100' => self::round1(self::num($r['C']) * $k),
                'FIBER_100' => self::round1(self::num($r['FI']) * $k),
                'SUGAR_100' => self::round1(self::num($r['S']) * $k),
                'FOOD_URL' => isset($r['FOOD_URL']) ? $r['FOOD_URL'] : '',
                'UPDATED' => date('Y-m-d H:i:s'),
            );
            $old = SQLSelectOne("SELECT * FROM tabcalorie_foods WHERE FOOD_GUID='" . DBSafe($r['FOOD_GUID']) . "'");
            if ($old['ID']) {
                $rec['ID'] = $old['ID'];
                // User-entered service data always wins over imported guesses.
                foreach (array('GI', 'NOTES', 'FOOD_ID', 'FOOD_URL', 'UNIT_GUID',
                    'UNIT_OPTIONS', 'DEFAULT_MULTIPLIER', 'DEFAULT_SLOT', 'SERVICE_JSON') as $keep) {
                    if (isset($old[$keep]) && $old[$keep] !== '') {
                        $rec[$keep] = $old[$keep];
                    }
                }
                SQLUpdate('tabcalorie_foods', $rec);
            } else {
                $rec['UNIT_GUID'] = '0000000000000001';
                $rec['DEFAULT_MULTIPLIER'] = self::round1($q / max(1, (int)$r['CNT']));
                $rec['DEFAULT_SLOT'] = 0;
                $rec['UNIT_OPTIONS'] = '';
                SQLInsert('tabcalorie_foods', $rec);
            }
            $n++;
        }
        return $n;
    }

    /** Full food record by ID (used by the write-back form and queue). */
    public static function foodRecord($id)
    {
        return SQLSelectOne("SELECT * FROM tabcalorie_foods WHERE ID=" . (int)$id);
    }

    /** Create or update a food record from the admin form. */
    public static function saveFoodRecord($data)
    {
        $id = (int)(isset($data['ID']) ? $data['ID'] : 0);
        $old = $id ? self::foodRecord($id) : array();
        $rec = array(
            'FOOD_GUID' => mb_substr(trim((string)(isset($data['FOOD_GUID']) ? $data['FOOD_GUID'] : '')), 0, 64),
            'FOOD_ID' => mb_substr(trim((string)(isset($data['FOOD_ID']) ? $data['FOOD_ID'] : '')), 0, 64),
            'TITLE' => mb_substr(trim((string)(isset($data['TITLE']) ? $data['TITLE'] : '')), 0, 255),
            'UNIT' => mb_substr(trim((string)(isset($data['UNIT']) ? $data['UNIT'] : 'g')), 0, 32),
            'FOOD_URL' => mb_substr(trim((string)(isset($data['FOOD_URL']) ? $data['FOOD_URL'] : '')), 0, 255),
            'UNIT_GUID' => mb_substr(trim((string)(isset($data['UNIT_GUID']) ? $data['UNIT_GUID'] : '0000000000000001')), 0, 64),
            'UNIT_OPTIONS' => mb_substr((string)(isset($data['UNIT_OPTIONS']) ? $data['UNIT_OPTIONS'] : ''), 0, 8000),
            'DEFAULT_MULTIPLIER' => self::round1(self::num(isset($data['DEFAULT_MULTIPLIER']) ? $data['DEFAULT_MULTIPLIER'] : 100)),
            'DEFAULT_SLOT' => max(0, min(6, (int)(isset($data['DEFAULT_SLOT']) ? $data['DEFAULT_SLOT'] : 0))),
            'GI' => max(0, min(200, self::num(isset($data['GI']) ? $data['GI'] : 0))),
            'NOTES' => mb_substr(strip_tags((string)(isset($data['NOTES']) ? $data['NOTES'] : '')), 0, 1000),
            'ENERGY_100' => self::round1(self::num(isset($data['ENERGY_100']) ? $data['ENERGY_100'] : 0)),
            'PROTEIN_100' => self::round1(self::num(isset($data['PROTEIN_100']) ? $data['PROTEIN_100'] : 0)),
            'FAT_100' => self::round1(self::num(isset($data['FAT_100']) ? $data['FAT_100'] : 0)),
            'CARB_100' => self::round1(self::num(isset($data['CARB_100']) ? $data['CARB_100'] : 0)),
            'FIBER_100' => self::round1(self::num(isset($data['FIBER_100']) ? $data['FIBER_100'] : 0)),
            'SUGAR_100' => self::round1(self::num(isset($data['SUGAR_100']) ? $data['SUGAR_100'] : 0)),
            'UPDATED' => date('Y-m-d H:i:s'),
        );
        if ($rec['FOOD_GUID'] === '') {
            $rec['FOOD_GUID'] = md5($rec['TITLE'] . '|' . $rec['FOOD_URL']);
        }
        if ($rec['FOOD_ID'] === '') {
            $rec['FOOD_ID'] = $rec['FOOD_GUID'];
        }
        if (isset($old['SERVICE_JSON']) && $old['SERVICE_JSON'] !== '') {
            $rec['SERVICE_JSON'] = $old['SERVICE_JSON'];
        }
        if ($old['ID']) {
            $rec['ID'] = $old['ID'];
            SQLUpdate('tabcalorie_foods', $rec);
            return (int)$old['ID'];
        }
        return (int)SQLInsert('tabcalorie_foods', $rec);
    }

    public static function deleteFoodRecord($id)
    {
        SQLExec("DELETE FROM tabcalorie_foods WHERE ID=" . (int)$id);
        return true;
    }

    public static function log($kind, $status, $httpCode, $rows, $message)
    {
        $rec = array(
            'RUN_AT' => date('Y-m-d H:i:s'),
            'KIND' => substr((string)$kind, 0, 32),
            'STATUS' => substr((string)$status, 0, 16),
            'HTTP_CODE' => (int)$httpCode,
            'ROWS' => (int)$rows,
            'MESSAGE' => mb_substr(preg_replace('/[\r\n\t]+/', ' ', strip_tags((string)$message)), 0, 500),
        );
        return SQLInsert('tabcalorie_sync_log', $rec);
    }

    /**
     * Retention cleanup: entries/days by data retention, sync log by age AND
     * row count (rotation), write queue by relevance period (TTL).
     */
    public static function cleanup($retentionDays, $cfg = array())
    {
        $days = max(30, (int)$retentionDays);
        $cut = date('Y-m-d', time() - $days * 86400);
        SQLExec("DELETE FROM tabcalorie_entries WHERE ENTRY_DATE<'" . DBSafe($cut) . "'");
        SQLExec("DELETE FROM tabcalorie_days WHERE DAY_DATE<'" . DBSafe($cut) . "'");
        SQLExec("DELETE FROM tabcalorie_activities WHERE ACTIVITY_DATE<'" . DBSafe($cut) . "'");

        $logDays = max(1, (int)(isset($cfg['LOG_RETENTION_DAYS']) ? $cfg['LOG_RETENTION_DAYS'] : 30));
        $logCut = date('Y-m-d H:i:s', time() - $logDays * 86400);
        SQLExec("DELETE FROM tabcalorie_sync_log WHERE RUN_AT<'" . DBSafe($logCut) . "'");
        $maxRows = max(100, (int)(isset($cfg['LOG_MAX_ROWS']) ? $cfg['LOG_MAX_ROWS'] : 2000));
        $cnt = SQLSelectOne("SELECT COUNT(*) AS N FROM tabcalorie_sync_log");
        if ((int)$cnt['N'] > $maxRows) {
            SQLExec("DELETE FROM tabcalorie_sync_log ORDER BY ID ASC LIMIT " . ((int)$cnt['N'] - $maxRows));
        }

        $ttl = max(1, (int)(isset($cfg['WRITE_QUEUE_TTL_DAYS']) ? $cfg['WRITE_QUEUE_TTL_DAYS'] : 7));
        $queueCut = date('Y-m-d H:i:s', time() - $ttl * 86400);
        SQLExec("DELETE FROM tabcalorie_write_queue WHERE CREATED_AT<'" . DBSafe($queueCut) .
            "' AND STATUS!='ns_sent'");
        // Nightscout de-duplication markers live as long as the underlying data.
        SQLExec("DELETE FROM tabcalorie_write_queue WHERE STATUS='ns_sent' AND CREATED_AT<'" .
            DBSafe($cut) . "'");
        return $cut;
    }

    /** All activity records for a day. */
    public static function activityRows($date)
    {
        return SQLSelect("SELECT * FROM tabcalorie_activities WHERE ACTIVITY_DATE='" . DBSafe($date) . "'
                          ORDER BY ID");
    }

    /** All dishes of a day, grouped by meal slot (slot_id => rows). */
    public static function dayDishes($date)
    {
        $rows = SQLSelect("SELECT ID, SLOT_ID, SLOT_TITLE, MEAL_TIME, TITLE, QUANTITY, UNIT, UNIT_RAW,
                           ENERGY, CARBOHYDRATE, PROTEIN, FAT, FIBER, SOURCE
                           FROM tabcalorie_entries WHERE ENTRY_DATE='" . DBSafe($date) . "'
                           ORDER BY SLOT_ID, ID");
        $out = array();
        foreach ($rows as $r) {
            $out[(int)$r['SLOT_ID']][] = $r;
        }
        return $out;
    }

    /**
     * Full raw payload for the last day that has at least one record:
     * original TK diary JSON plus normalized entries and activities.
     */
    public static function rawPayload($date = null)
    {
        if (!$date) {
            $date = self::lastFilledDate();
        }
        $day = SQLSelectOne("SELECT RAW_JSON FROM tabcalorie_days WHERE DAY_DATE='" . DBSafe($date) . "'");
        $diary = array();
        if (!empty($day['RAW_JSON'])) {
            $decoded = json_decode($day['RAW_JSON'], true);
            if (is_array($decoded)) {
                $diary = $decoded;
            }
        }
        $payload = array(
            'date' => $date,
            'diary' => $diary,
            'entries' => SQLSelect("SELECT * FROM tabcalorie_entries WHERE ENTRY_DATE='" . DBSafe($date) . "'
                                    ORDER BY SLOT_ID, ID"),
            'activities' => self::activityRows($date),
        );
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return mb_strcut((string)$json, 0, self::MAX_RAW_BYTES, 'UTF-8');
    }

    /** Only allow public HTTPS hosts without embedded credentials (SSRF guard). */
    public static function validRemoteUrl($url)
    {
        $p = parse_url((string)$url);
        if (!$p || !isset($p['scheme'], $p['host']) || strtolower($p['scheme']) !== 'https') {
            return false;
        }
        if (isset($p['user']) || isset($p['pass'])) {
            return false;
        }
        $host = $p['host'];
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return false;
        }
        $ip = gethostbyname($host);
        if ($ip === $host || filter_var($ip, FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
            return false;
        }
        return true;
    }

    /** Exponential backoff: 60s, 120s, 240s ... capped at 1 hour. */
    public static function backoffSeconds($failCount)
    {
        $n = max(1, (int)$failCount);
        return (int)min(3600, 60 * pow(2, $n - 1));
    }

    /**
     * Integration status for the object: 0 on any problem or when the background
     * cycle is disabled/stale, 1 when everything looks healthy.
     */
    public static function computeStatus($cfg)
    {
        if ((int)(isset($cfg['SYNC_ENABLED']) ? $cfg['SYNC_ENABLED'] : 0) !== 1) {
            return 0;
        }
        if (!empty($cfg['LAST_ERROR'])) {
            return 0;
        }
        if ((int)(isset($cfg['CIRCUIT_UNTIL']) ? $cfg['CIRCUIT_UNTIL'] : 0) > time()) {
            return 0;
        }
        $last = (int)getGlobal('cycle_tabcalorieRunTs');
        if ($last <= 0) {
            $last = (int)getGlobal('cycle_tabcalorieRun');
        }
        if ($last <= 0 || time() - $last > 600) {
            return 0;
        }
        return 1;
    }

    public static function dayRows($from, $to)
    {
        return SQLSelect("SELECT * FROM tabcalorie_days WHERE DAY_DATE>='" . DBSafe($from) . "'
                          AND DAY_DATE<='" . DBSafe($to) . "' ORDER BY DAY_DATE");
    }

    public static function entryRows($from, $to)
    {
        return SQLSelect("SELECT ENTRY_DATE, SLOT_ID, SLOT_TITLE, TITLE, UNIT_RAW, QUANTITY, UNIT,
                          ENERGY, PROTEIN, FAT, CARBOHYDRATE, FIBER, SUGAR, SOURCE
                          FROM tabcalorie_entries WHERE ENTRY_DATE>='" . DBSafe($from) . "'
                          AND ENTRY_DATE<='" . DBSafe($to) . "' ORDER BY ENTRY_DATE, SLOT_ID");
    }

    public static function queueWrite($entryId, $payload)
    {
        $rec = array(
            'ENTRY_ID' => (int)$entryId,
            'PAYLOAD' => json_encode($payload, JSON_UNESCAPED_UNICODE),
            'STATUS' => 'draft',
            'CREATED_AT' => date('Y-m-d H:i:s'),
        );
        return SQLInsert('tabcalorie_write_queue', $rec);
    }

    public static function writeQueue($limit = 50)
    {
        return SQLSelect("SELECT * FROM tabcalorie_write_queue ORDER BY ID DESC LIMIT " . max(1, (int)$limit));
    }

    /** Nightscout de-duplication marker stored in the same queue table. */
    public static function nsSent($date, $slot)
    {
        $needle = '%"date":"' . DBSafe($date) . '","slot":' . (int)$slot . '%';
        $rec = SQLSelectOne("SELECT ID FROM tabcalorie_write_queue WHERE STATUS='ns_sent' AND PAYLOAD LIKE '" . $needle . "'");
        return (bool)$rec['ID'];
    }

    public static function markNsSent($date, $slot, $message)
    {
        $id = self::queueWrite(0, array('kind' => 'ns', 'date' => $date, 'slot' => (int)$slot));
        self::setWriteStatus($id, 'ns_sent', $message);
        return $id;
    }

    public static function setWriteStatus($id, $status, $message)
    {
        $rec = SQLSelectOne("SELECT * FROM tabcalorie_write_queue WHERE ID=" . (int)$id);
        if (!$rec['ID']) {
            return false;
        }
        $rec['STATUS'] = substr((string)$status, 0, 16);
        $rec['MESSAGE'] = mb_substr((string)$message, 0, 300);
        $rec['SENT_AT'] = date('Y-m-d H:i:s');
        SQLUpdate('tabcalorie_write_queue', $rec);
        return true;
    }
}
